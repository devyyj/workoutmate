<template>
  <b-container>
    <Nuxt />
  </b-container>
</template>

<style></style>
