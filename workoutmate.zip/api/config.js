module.exports = {
  db: {
    dialect: 'mariadb',
    user: 'root',
    pass: 'asdf12!@',
    // host: '13.125.102.235',
    host: 'localhost',
    port: '3306',
    name: 'workoutmate',
  },
}
