<template>
  <div>
    <b-row>
      <card v-for="(item, index) in items" :key="index" :item="item"></card>
    </b-row>
  </div>
</template>

<script>
import axios from 'axios'
import card from '../components/card'

export default {
  components: {
    card,
  },
  async asyncData() {
    const { data } = await axios.get(`http://localhost:8080/api/cards`)
    return { items: data }
  },
}
</script>

<style></style>
